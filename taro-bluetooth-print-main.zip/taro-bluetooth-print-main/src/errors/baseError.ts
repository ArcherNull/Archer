/**
 * Custom error codes for Bluetooth printing operations
 */
export enum ErrorCode {
  // Connection errors
  CONNECTION_FAILED = 'CONNECTION_FAILED',
  CONNECTION_TIMEOUT = 'CONNECTION_TIMEOUT',
  DEVICE_NOT_FOUND = 'DEVICE_NOT_FOUND',
  DEVICE_DISCONNECTED = 'DEVICE_DISCONNECTED',

  // Service discovery errors
  SERVICE_NOT_FOUND = 'SERVICE_NOT_FOUND',
  CHARACTERISTIC_NOT_FOUND = 'CHARACTERISTIC_NOT_FOUND',
  SERVICE_DISCOVERY_FAILED = 'SERVICE_DISCOVERY_FAILED',

  // Write errors
  WRITE_FAILED = 'WRITE_FAILED',
  WRITE_TIMEOUT = 'WRITE_TIMEOUT',

  // Print job errors
  PRINT_JOB_IN_PROGRESS = 'PRINT_JOB_IN_PROGRESS',
  PRINT_JOB_CANCELLED = 'PRINT_JOB_CANCELLED',
  PRINT_JOB_FAILED = 'PRINT_JOB_FAILED',

  // Configuration errors
  INVALID_CONFIGURATION = 'INVALID_CONFIGURATION',
  ENCODING_NOT_SUPPORTED = 'ENCODING_NOT_SUPPORTED',

  // Data errors
  INVALID_IMAGE_DATA = 'INVALID_IMAGE_DATA',
  INVALID_QR_DATA = 'INVALID_QR_DATA',

  // Platform errors
  PLATFORM_NOT_SUPPORTED = 'PLATFORM_NOT_SUPPORTED',

  // Queue errors
  QUEUE_FULL = 'QUEUE_FULL',
  QUEUE_JOB_NOT_FOUND = 'QUEUE_JOB_NOT_FOUND',

  // Preview errors
  PREVIEW_FAILED = 'PREVIEW_FAILED',
}

/**
 * Custom error class for Bluetooth printing operations
 *
 * @example
 * ```typescript
 * throw new BluetoothPrintError(
 *   ErrorCode.CONNECTION_FAILED,
 *   'Failed to connect to device',
 *   originalError
 * );
 * ```
 */
export class BluetoothPrintError extends Error {
  /**
   * Creates a new BluetoothPrintError
   *
   * @param code - Error code from ErrorCode enum
   * @param message - Human-readable error message
   * @param originalError - Original error that caused this error (optional)
   */
  constructor(
    public readonly code: ErrorCode,
    message: string,
    public readonly originalError?: Error
  ) {
    super(message);
    this.name = 'BluetoothPrintError';

    // Maintains proper stack trace for where error was thrown (only available on V8)
    if (Error.captureStackTrace) {
      Error.captureStackTrace(this, BluetoothPrintError);
    }
  }

  /**
   * Returns a detailed error message including the error code and stack trace
   */
  toString(): string {
    let result = `${this.name} [${this.code}]: ${this.message}`;
    if (this.originalError) {
      result += `\nCaused by: ${this.originalError.message}`;
      if (this.originalError.stack) {
        result += `\n${this.originalError.stack}`;
      }
    }
    if (this.stack) {
      result += `\n${this.stack}`;
    }
    return result;
  }

  /**
   * Converts the error to a JSON object
   * Useful for logging and debugging
   */
  toJSON(): object {
    return {
      name: this.name,
      code: this.code,
      message: this.message,
      stack: this.stack,
      originalError: this.originalError
        ? {
            name: this.originalError.name,
            message: this.originalError.message,
            stack: this.originalError.stack,
          }
        : undefined,
    };
  }
}
