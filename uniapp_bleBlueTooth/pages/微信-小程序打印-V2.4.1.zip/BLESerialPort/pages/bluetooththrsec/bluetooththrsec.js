const app = getApp()
var util = require('../../utils/util.js');
var gbk = require('../../utils/printUtil-GBK.js');
var pako = require('pako');

import * as zksdk from '../../utils/bluetoolth';
var recArrayBuff = new ArrayBuffer(256);
var recLen =0;
const errMsg = {
    10000: '未初始化蓝牙模块',
    10001: '蓝牙未打开',
    10002: '没有找到指定设备',
    10003: '连接失败',
    10004: '没有找到指定服务',
    10005: '没有找到指定特征值',
    10006: '当前连接已断开',
    10007: '当前特征值不支持此操作',
    10008: '系统上报异常',
    10009: '系统版本低于 4.3 不支持BLE'
};

/**
 * 连接设备。获取数据
 */
Page({
    data: {
        deviceId: '',
        name: '',
        services: [],
        serviceId: '', 
        writeId:'',
        readId:'',
        SERVERMAINSERVER:'',
        WRITEMAINSERVER:'',
        btn_disabled: true,
        result:'' ,
        State:'',
        Dev_mac:'',
        showViewWiFi: false,
        showViewLAN: false,
        WiFiAPName:' ',
        WiFiAPGetFlg:false,
        LANIP:'',
        LANMask:'',
        LANGateWay:'',
        MTUSize:20
    },
    //---连接成功----
    onConnectSuccess(res){   
      var that = this;   
      console.log('onConnectSuccess', res); 
      zksdk.getBLEDeviceServices(that.data.deviceId, this.onGetServicesSuccess, this.onGetServicesFail);      
    },
    //---连接失败----
    onConnectFail(res){    
      console.log('onConnectFail', res);        
    },
    //---Services获取成功----
    onGetServicesSuccess(res){    
      var that = this;  
      console.log('onGetServicesSuccess', res); 
      this.setData({ services: res.serviceId });    
      zksdk.getDeviceCharacteristics(that.data.deviceId, that.data.services, this.onGetCharacterSuccess, this.onGetCharacterFail);
    },
    //---Services获取失败----
    onGetServicesFail(res){    
      console.log('onGetServicesFail', res);        
    },
    //---Characteristics获取成功----
    onGetCharacterSuccess(res){
        console.log('onGetCharacterSuccess servid ', res.serviceId);      
        console.log('write character ',res.writeId);
        console.log('read character ',res.readId);
        this.setData({ 
            serviceId: res.serviceId,  
            writeId: res.writeId, 
            readId: res.readId,
        });          
        this.setData({btn_disabled:false});
        console.log('Enable button');
        //---停止扫描蓝牙设备---------
        zksdk.stopBlueDevicesDiscovery();
        //-----打开状态通知功能------
        const opt = { 
          deviceId: this.data.deviceId, 
          serviceId: this.data.serviceId, 
          characteristicId: this.data.readId,         
        };
        zksdk.onGetBLECharacteristicValueChange(opt,this.onGetBLEValueChange);
    },
    //---Characteristics获取失败----
    onGetCharacterFail(res){
      console.log('onGetCharacterFail', res);
    },
        
    onLoad: function (opt) {
      var that = this;        
      //var serv_id = '0000FFF0-0000-1000-8000-00805F9B34FB'
      console.log("bluetooththrsec onLoad");
      // 生命周期函数--监听页面加载
      showViewWiFi: (opt.showViewWiFi == "true" ? true : false)
      showViewLAN: (opt.showViewLAN == "true" ? true : false)

      var LANIP = wx.getStorageSync('LANIP');
      var LANMask = wx.getStorageSync('LANMask');
      var LANGateWay = wx.getStorageSync('LANGateWay');
      that.setData({  LANIPValue: LANIP  });
      that.setData({  LANMaskValue: LANMask  });
      that.setData({  LANGateWayValue: LANGateWay  });
      that.data.LANIP=LANIP;
      that.data.LANMask=LANMask; 
      that.data.LANGateWay=LANGateWay;

      var MTUSize = wx.getStorageSync('MTUSize');
      if(MTUSize != undefined){
        that.setData({  MTUSize: MTUSize  });
        that.data.MTUSize=MTUSize;
      }
      else{
        that.setData({  MTUSize: 20  });
        that.data.MTUSize=20;
      }
      console.log('deviceId=' + opt.deviceId);
      console.log('name=' + opt.name);
      that.setData({btn_disabled:true});
      console.log('Disable button');
      that.setData({deviceId: opt.deviceId,name: opt.name});
      // 监听设备的连接状态
      wx.onBLEConnectionStateChange(function (res) {
         console.log(`device ${res.deviceId} state has changed, connected: ${res.connected}`)
      })

      zksdk.createBLEConnection(that.data.deviceId, this.onConnectSuccess, this.onConnectFail);  
    },    

    //------Characteristic信息变化回调-------
    onGetBLEValueChange:function(res){
      var that = this;
      console.log(`characteristic ${res.characteristicId} has changed, now is ${res.value}`)
      console.log(util.ab2hex(res.value))
      //if (res.characteristicId == `0000FFF1-0000-1000-8000-00805F9B34FB`)
      {                                            
          var view1 = new DataView(res.value);
          //console.log(res.value.byteLength);
          //console.log(view1.getUint8(0));
          //console.log(view1.getUint8(2));
          if (res.value.byteLength >= 4 && view1.getUint8(0) == 0x1d && view1.getUint8(1)==0x99){
            let strSta=" ";
            if (view1.getUint8(2) == 0) strSta = "正常";                                       
            if (view1.getUint8(2) & 0x01) strSta=strSta+ ' 缺纸';
            if (view1.getUint8(2) & 0x02)  strSta=strSta + ' 开盖' ;                                             
            if (view1.getUint8(2) & 0x04) strSta=strSta + ' 打印头过热';                                              
            if (view1.getUint8(2) & 0x08) strSta=strSta + ' 定位失败';                                            
            if (view1.getUint8(2) & 0x10) strSta=strSta +' 低电';  
            if (view1.getUint8(2) & 0x20) strSta=strSta + ' 正在打印';
            that.setData({ State: strSta }) 
          }
          else if(res.value.byteLength >= 9 && view1.getUint8(0) == 0x20 && view1.getUint8(1)==0x06){ 
            //---MAC地址获取----             
              let buffer = new ArrayBuffer(6)
              let dataView = new DataView(buffer)
              for(var i=0;i<6;i++) dataView.setUint8(i, view1.getUint8(3+i)); 

              let dev_mac=buffer.join(":");
              that.setData({ Dev_mac: dev_mac });   
              console.log('mac:'+dev_mac);
          }
          else if (res.value.byteLength >= 3 && view1.getUint8(0) == 0x1D && view1.getUint8(1)==0x49 && view1.getUint8(2)==0x4A){
            let len = res.value.byteLength            
            let dataView = new DataView(recArrayBuff)
            recLen=0;
            for(var i=0;i<len-3;i++) dataView.setUint8(i, view1.getUint8(3+i));
            recLen=len-3;
          }
          else if (res.value.byteLength >= 3 && view1.getUint8(0) == 0x30 && view1.getUint8(1)==0x00 && view1.getUint8(1)==0x00){
            console.log('Resp OK');
          }
          else{
            if (that.WiFiAPGetFlg) {
              let len = res.value.byteLength;
              let dataView = new DataView(recArrayBuff)
              for (var i = 0; i < len; i++) dataView.setUint8(i + recLen, view1.getUint8(i));
              recLen += len
              if (view1.getUint8(len - 1) == 0 || view1.getUint8(len - 1) == 0x0A) {
                that.WiFiAPName = util.Utf8ArrayToStr(new Uint8Array(recArrayBuff));
                console.log(that.WiFiAPName)
                that.setData({ WiFiAPName: that.WiFiAPName })
                recLen = 0;
              }
              that.data.timer = setTimeout(
                function () {
                  // TODO 你需要执行的任务
                  console.log('startTimer  500毫秒后执行一次任务')
                  var Scan = util.Utf8ArrayToStr(new Uint8Array(recArrayBuff));
                  console.log(Scan)
                  that.setData({ WiFiAPName: that.WiFiAPName })
                  recLen = 0;
                  that.WiFiAPGetFlg=false;
                }, 500);
            }
            else{
              var Scan = util.Utf8ArrayToStr(new Uint8Array(res.value));
              console.log(Scan)
              that.setData({ State: Scan })
              this.bindViewTap1(null,Scan);           
            }
        }
      }
    },

    //------打印机状态获取----------
    btn_GetState:function(){
      console.log('GetState')
      var that = this;
      let buffer = new ArrayBuffer(2)
      let dataView = new DataView(buffer)
      dataView.setUint8(0, 0x1D)
      dataView.setUint8(1, 0x99)      
      let len=20;
      const optWt = { 
          deviceId: this.data.deviceId, 
          serviceId: this.data.serviceId, 
          characteristicId: this.data.writeId,
          value:buffer,
          lasterSuccess: this.onSendSuccess,
          onceLength:len
      };      
      zksdk.sendDataToDevice(optWt);
    },
    //------WiFi列表获取----------
    btn_WiFiAP:function(){
      console.log('Get WiFi AP List')
      var that = this;
      let buffer = new ArrayBuffer(3)
      let dataView = new DataView(buffer)
      dataView.setUint8(0, 0x1D)
      dataView.setUint8(1, 0x49)
      dataView.setUint8(2, 0x4A)
      let len=20;
      const optWt = { 
          deviceId: this.data.deviceId, 
          serviceId: this.data.serviceId, 
          characteristicId: this.data.writeId,
          value:buffer,
          lasterSuccess: this.onSendSuccess,
          onceLength:len
      };      
      zksdk.sendDataToDevice(optWt);
      that.WiFiAPGetFlg=true;

    },
    //---数据全部发送成功回调----
    onSendSuccess:function(){
      console.log("onSendSuccess");
    },

    MTUInput: function (e) {
      var that = this;
      that.setData({
        MTUSize: e.detail.value
      })
      that.data.MTUSize=e.detail.value;
      wx.setStorageSync('MTUSize', e.detail.value);
      console.log('that.data.MTUSize:', that.data.MTUSize)
    },

    /**
     * 打印指令测试
     */
    bindViewTap1: function (options, barcode='0') {
      var that = this;
      //let buffer = wx.base64ToArrayBuffer("");  
      let strCmd ="! 0 200 200 748 1\nPAGE-WIDTH 576\nLEFT\nBOX 10 10 560 740 3\nL 10 130 560 130 3\nL 10 170 560 170 3\nL 10 210 560 210 3\nL 10 250 560 250 3\nL 10 290 560 290 3\nL 10 330 560 330 3\nL 10 370 560 370 3\nL 10 410 560 410 3\nL 10 450 560 450 3\nL 10 490 560 490 3\nL 10 530 560 530 3\nL 10 570 560 570 3\nL 10 610 560 610 3\nSETBOLD 1\nSETMAG 1 2\nT 0 24 20 20 石家庄安邦物流安宝达运单\nSETBOLD 0\nSETMAG 1 1\nT 0 24 20 70 安邦物流园B区1号0311-89899808\nT 0 24 20 100 18233116611微\nT 0 24 20 140 单号:<barcode>  2020/12/12\nT 0 24 20 180 石家庄\nT 0 24 20 22015732184595\nT 0 24 20 260 数量：1                        货物名称：桌子\nT 0 24 20 300 发货人：杨龙 15863586585\nT 0 24 20 340 收货人：杨 4868268528633\nT 0 24 20 380 现付：1元                     到付：2元\nT 0 24 20 420 回单付：                      回单要求：无\nT 0 24 20 460 中转送货费：                 服务器方式：自提\nT 0 24 20 500  代收货款：                   包装方式：无\nT 0 24 20 540 小程序：物流专线联合   垫付：\nT 0 24 20 580 重量：                         体积：\nT 0 24 20 620 备注：\nCENTER\nB 128 2 1 40 20 660 <barcode>\nT 0 24 20 710 <barcode>\nGAP-SENSE\nFORM\nPRINT\n";
      console.log(barcode)
      if(barcode == undefined) barcode="0"
      strCmd=strCmd.replace('<barcode>',barcode);
      strCmd=strCmd.replace('<barcode>',barcode);
      strCmd=strCmd.replace('<barcode>',barcode);
      /*
      let strCmd =zksdk.CreatCPCLPage(570,500,1,0);  
      strCmd += zksdk.addCPCLBox(0,0,560,490,3);
      strCmd += zksdk.addCPCLLine(0,210,560,210,3);
      strCmd += zksdk.addCPCLText(10,0,'4','3',0,'8.14');
      strCmd += zksdk.addCPCLBarCode(270,0,'128',80,0,1,1,'00051');
      strCmd += zksdk.addCPCLText(290,80,'7','2',0,'00051');
      strCmd += zksdk.addCPCLText(40,110,'3','0',0,'CHICKEN FEET (BONELESS)-Copy-Copy');
      strCmd += zksdk.addCPCLSETMAG(2,2);
      strCmd += zksdk.addCPCLText(40,150,'55','0',0,'无骨鸡爪 一盒（约1.5磅）。，,:：');
      strCmd += zksdk.addCPCLText(350,220,'0','24',0,'。，,:：');
      strCmd += zksdk.addCPCLText(350,260,'24','0',0,'。，,:：');
      strCmd += zksdk.addCPCLSETMAG(0,0);
      strCmd += zksdk.addCPCLText(350,180,'7','2',0,'2019-08-12');
      //注意换行需要\r\n,单\n不行
      strCmd += zksdk.addCPCLMLText(10,220,'0','24','30','多行测试。，,:：\r\n1st line of text\r\n2nd line of text\r\n');
      strCmd += zksdk.addCPCLLocation(2);
      strCmd += zksdk.addCPCLQRCode(0,320,'M', 2, 6, 'qr code test');
      //strCmd += zksdk.addCPCLGAP();
      strCmd += zksdk.addCPCLPrint();*/
      console.log(strCmd);
      
      let buffer = gbk.strToGBKByte(strCmd);
      console.log(buffer);

      //buffer=pako.myGzip(buffer);
      //console.log(buffer)

      var datalen=that.data.MTUSize;
      if(datalen<20 || datalen>500){
        console.log('MTUSize error:', datalen)
        datalen=20;
      }
      console.log('MTUSize:', datalen)
      /*if (app.globalData.platform == 'ios')
      {
        console.log('platform:', app.globalData.platform)          
        datalen=120
      }*/
      const opt = { 
        deviceId: this.data.deviceId, 
        serviceId: this.data.serviceId, 
        characteristicId: this.data.writeId,
        value:buffer,
        lasterSuccess: this.onSendSuccess,
        onceLength:datalen
      };
      //const opt = { deviceId: this.data.deviceId, ...this.character };
      zksdk.sendDataToDevice(opt);
  },
  bindViewTap11: function (options, barcode='0') {
    var that = this;
    let strCmd ="! 0 200 200 748 1\nPAGE-WIDTH 576\nLEFT\nBOX 10 10 560 740 3\nL 10 130 560 130 3\nL 10 170 560 170 3\nL 10 210 560 210 3\nL 10 250 560 250 3\nL 10 290 560 290 3\nL 10 330 560 330 3\nL 10 370 560 370 3\nL 10 410 560 410 3\nL 10 450 560 450 3\nL 10 490 560 490 3\nL 10 530 560 530 3\nL 10 570 560 570 3\nL 10 610 560 610 3\nSETBOLD 1\nSETMAG 1 2\nT 0 24 20 20 石家庄安邦物流安宝达运单\nSETBOLD 0\nSETMAG 1 1\nT 0 24 20 70 安邦物流园B区1号0311-89899808\nT 0 24 20 100 18233116611微\nT 0 24 20 140 单号:<barcode>  2020/12/12\nT 0 24 20 180 石家庄\nT 0 24 20 22015732184595\nT 0 24 20 260 数量：1                        货物名称：桌子\nT 0 24 20 300 发货人：杨龙 15863586585\nT 0 24 20 340 收货人：杨 4868268528633\nT 0 24 20 380 现付：1元                     到付：2元\nT 0 24 20 420 回单付：                      回单要求：无\nT 0 24 20 460 中转送货费：                 服务器方式：自提\nT 0 24 20 500  代收货款：                   包装方式：无\nT 0 24 20 540 小程序：物流专线联合   垫付：\nT 0 24 20 580 重量：                         体积：\nT 0 24 20 620 备注：\nCENTER\nB 128 2 1 40 20 660 <barcode>\nT 0 24 20 710 <barcode>\nGAP-SENSE\nFORM\nPRINT\n";
    console.log(barcode)
    if(barcode == undefined) barcode="0"
    strCmd=strCmd.replace('<barcode>',barcode);
    strCmd=strCmd.replace('<barcode>',barcode);
    strCmd=strCmd.replace('<barcode>',barcode);     
    let buffer = gbk.strToGBKByte(strCmd);
    //buffer=pako.myGzip(buffer);
    var datalen=100;
    
    const opt = { 
      deviceId: this.data.deviceId, 
      serviceId: this.data.serviceId, 
      characteristicId: this.data.writeId,
      value:buffer,
      lasterSuccess: this.onSendSuccess,
      onceLength:datalen
    };
    zksdk.sendDataToDevice(opt);
  },
  bindViewTap12: function (options, barcode='0') {
    var that = this;
    let strCmd ="! 0 200 200 748 1\nPAGE-WIDTH 576\nLEFT\nBOX 10 10 560 740 3\nL 10 130 560 130 3\nL 10 170 560 170 3\nL 10 210 560 210 3\nL 10 250 560 250 3\nL 10 290 560 290 3\nL 10 330 560 330 3\nL 10 370 560 370 3\nL 10 410 560 410 3\nL 10 450 560 450 3\nL 10 490 560 490 3\nL 10 530 560 530 3\nL 10 570 560 570 3\nL 10 610 560 610 3\nSETBOLD 1\nSETMAG 1 2\nT 0 24 20 20 石家庄安邦物流安宝达运单\nSETBOLD 0\nSETMAG 1 1\nT 0 24 20 70 安邦物流园B区1号0311-89899808\nT 0 24 20 100 18233116611微\nT 0 24 20 140 单号:<barcode>  2020/12/12\nT 0 24 20 180 石家庄\nT 0 24 20 22015732184595\nT 0 24 20 260 数量：1                        货物名称：桌子\nT 0 24 20 300 发货人：杨龙 15863586585\nT 0 24 20 340 收货人：杨 4868268528633\nT 0 24 20 380 现付：1元                     到付：2元\nT 0 24 20 420 回单付：                      回单要求：无\nT 0 24 20 460 中转送货费：                 服务器方式：自提\nT 0 24 20 500  代收货款：                   包装方式：无\nT 0 24 20 540 小程序：物流专线联合   垫付：\nT 0 24 20 580 重量：                         体积：\nT 0 24 20 620 备注：\nCENTER\nB 128 2 1 40 20 660 <barcode>\nT 0 24 20 710 <barcode>\nGAP-SENSE\nFORM\nPRINT\n";
    console.log(barcode)
    if(barcode == undefined) barcode="0"
    strCmd=strCmd.replace('<barcode>',barcode);
    strCmd=strCmd.replace('<barcode>',barcode);
    strCmd=strCmd.replace('<barcode>',barcode);     
    let buffer = gbk.strToGBKByte(strCmd);
    //buffer=pako.myGzip(buffer);
    var datalen=180;
    
    const opt = { 
      deviceId: this.data.deviceId, 
      serviceId: this.data.serviceId, 
      characteristicId: this.data.writeId,
      value:buffer,
      lasterSuccess: this.onSendSuccess,
      onceLength:datalen
    };
    zksdk.sendDataToDevice(opt);
  },
  bindViewTap13: function (options, barcode='0') {
    var that = this;
    let strCmd ="! 0 200 200 748 1\nPAGE-WIDTH 576\nLEFT\nBOX 10 10 560 740 3\nL 10 130 560 130 3\nL 10 170 560 170 3\nL 10 210 560 210 3\nL 10 250 560 250 3\nL 10 290 560 290 3\nL 10 330 560 330 3\nL 10 370 560 370 3\nL 10 410 560 410 3\nL 10 450 560 450 3\nL 10 490 560 490 3\nL 10 530 560 530 3\nL 10 570 560 570 3\nL 10 610 560 610 3\nSETBOLD 1\nSETMAG 1 2\nT 0 24 20 20 石家庄安邦物流安宝达运单\nSETBOLD 0\nSETMAG 1 1\nT 0 24 20 70 安邦物流园B区1号0311-89899808\nT 0 24 20 100 18233116611微\nT 0 24 20 140 单号:<barcode>  2020/12/12\nT 0 24 20 180 石家庄\nT 0 24 20 22015732184595\nT 0 24 20 260 数量：1                        货物名称：桌子\nT 0 24 20 300 发货人：杨龙 15863586585\nT 0 24 20 340 收货人：杨 4868268528633\nT 0 24 20 380 现付：1元                     到付：2元\nT 0 24 20 420 回单付：                      回单要求：无\nT 0 24 20 460 中转送货费：                 服务器方式：自提\nT 0 24 20 500  代收货款：                   包装方式：无\nT 0 24 20 540 小程序：物流专线联合   垫付：\nT 0 24 20 580 重量：                         体积：\nT 0 24 20 620 备注：\nCENTER\nB 128 2 1 40 20 660 <barcode>\nT 0 24 20 710 <barcode>\nGAP-SENSE\nFORM\nPRINT\n";
    console.log(barcode)
    if(barcode == undefined) barcode="0"
    strCmd=strCmd.replace('<barcode>',barcode);
    strCmd=strCmd.replace('<barcode>',barcode);
    strCmd=strCmd.replace('<barcode>',barcode);     
    let buffer = gbk.strToGBKByte(strCmd);
    //buffer=pako.myGzip(buffer);
    var datalen=185;
    
    const opt = { 
      deviceId: this.data.deviceId, 
      serviceId: this.data.serviceId, 
      characteristicId: this.data.writeId,
      value:buffer,
      lasterSuccess: this.onSendSuccess,
      onceLength:datalen
    };
    zksdk.sendDataToDevice(opt);
  },
  bindViewTap14: function (options, barcode='0') {
    var that = this;
    let strCmd ="! 0 200 200 748 1\nPAGE-WIDTH 576\nLEFT\nBOX 10 10 560 740 3\nL 10 130 560 130 3\nL 10 170 560 170 3\nL 10 210 560 210 3\nL 10 250 560 250 3\nL 10 290 560 290 3\nL 10 330 560 330 3\nL 10 370 560 370 3\nL 10 410 560 410 3\nL 10 450 560 450 3\nL 10 490 560 490 3\nL 10 530 560 530 3\nL 10 570 560 570 3\nL 10 610 560 610 3\nSETBOLD 1\nSETMAG 1 2\nT 0 24 20 20 石家庄安邦物流安宝达运单\nSETBOLD 0\nSETMAG 1 1\nT 0 24 20 70 安邦物流园B区1号0311-89899808\nT 0 24 20 100 18233116611微\nT 0 24 20 140 单号:<barcode>  2020/12/12\nT 0 24 20 180 石家庄\nT 0 24 20 22015732184595\nT 0 24 20 260 数量：1                        货物名称：桌子\nT 0 24 20 300 发货人：杨龙 15863586585\nT 0 24 20 340 收货人：杨 4868268528633\nT 0 24 20 380 现付：1元                     到付：2元\nT 0 24 20 420 回单付：                      回单要求：无\nT 0 24 20 460 中转送货费：                 服务器方式：自提\nT 0 24 20 500  代收货款：                   包装方式：无\nT 0 24 20 540 小程序：物流专线联合   垫付：\nT 0 24 20 580 重量：                         体积：\nT 0 24 20 620 备注：\nCENTER\nB 128 2 1 40 20 660 <barcode>\nT 0 24 20 710 <barcode>\nGAP-SENSE\nFORM\nPRINT\n";
    console.log(barcode)
    if(barcode == undefined) barcode="0"
    strCmd=strCmd.replace('<barcode>',barcode);
    strCmd=strCmd.replace('<barcode>',barcode);
    strCmd=strCmd.replace('<barcode>',barcode);     
    let buffer = gbk.strToGBKByte(strCmd);
    //buffer=pako.myGzip(buffer);
    var datalen=200;
    
    const opt = { 
      deviceId: this.data.deviceId, 
      serviceId: this.data.serviceId, 
      characteristicId: this.data.writeId,
      value:buffer,
      lasterSuccess: this.onSendSuccess,
      onceLength:datalen
    };
    zksdk.sendDataToDevice(opt);
  },
  
  
  //---获取设备传统蓝牙MAC地址----
  GetDevBTMac: function () {
    var that = this;
    var a1 = that.GetDevicePar("BLUETOOTH_ADDR", 3);
    //console.log('a1', a1);
    let buffer = new ArrayBuffer(a1.byteLength);
    var vb = new Uint8Array(buffer, 0);
    var vblen = 0;
    let data = new Uint8Array(a1, 0, a1.byteLength);
    var datalen=20;
    if (app.globalData.platform == 'ios')
    {
      console.log('platform:', app.globalData.platform)          
      datalen=120;
    }
    for (var i = 0; i < a1.byteLength; i++) vb[vblen++] = data[i];    
    console.log('buffer:', buffer);

      const opt = { 
        deviceId: this.data.deviceId, 
        serviceId: this.data.serviceId, 
        characteristicId: this.data.writeId,
        value:buffer,
        lasterSuccess: this.onSendSuccess,
        onceLength:datalen
      };
      //const opt = { deviceId: this.data.deviceId, ...this.character };
      zksdk.sendDataToDevice(opt);
  },
  //----打印二维码-------
  bindViewTap2: function () {
    var that = this;    
    let strCmd1 = zksdk.CreatCPCLPage(576,300,1);
    strCmd1 += zksdk.addCPCLLocation(2);
    let strCmd2 = zksdk.addCPCLQRCode(10,10,'M', 2, 5, "中文二维码测试");
    let strCmd3 = zksdk.addCPCLText(10,150,'24','0',0,"中文二维码测试");
    strCmd3 += zksdk.addCPCLPrint();
    var byte1 = gbk.strToGBKByte(strCmd1);
    var byte2 = gbk.stringToArrayBuffer(strCmd2);
    var byte3 = gbk.strToGBKByte(strCmd3);
    var bytes = new ArrayBuffer(byte1.byteLength+byte2.byteLength+byte3.byteLength);
    var dv=new DataView(bytes);
    var dv1=new DataView(byte1);
    var dv2=new DataView(byte2);
    var dv3=new DataView(byte3);
    for(var i=0;i<byte1.byteLength;i++){
      dv.setInt8(i,dv1.getInt8(i));
    }
    for(var i=0;i<byte2.byteLength;i++){
      dv.setInt8(byte1.byteLength+i,dv2.getInt8(i));
    }
    for(var i=0;i<byte3.byteLength;i++){
      dv.setInt8(byte1.byteLength+byte2.byteLength+i,dv3.getInt8(i));
    }

    bytes=pako.myGzip(bytes);
    console.log(bytes)

      var datalen=20;
      if (app.globalData.platform == 'ios')
      {
        console.log('platform:', app.globalData.platform)          
        datalen=120;
      }

      const opt = { 
        deviceId: this.data.deviceId, 
        serviceId: this.data.serviceId, 
        characteristicId: this.data.writeId,
        value: bytes,
        lasterSuccess: this.onSendSuccess,
        onceLength:datalen
      };
      //const opt = { deviceId: this.data.deviceId, ...this.character };
      zksdk.sendDataToDevice(opt);      
  },
  //----打印图片-------
  bindViewTap3: function () {
    var that = this;

    const ctx = wx.createCanvasContext('secondCanvas');
    //选择一张图片
    wx.chooseImage({
      success: (res) => {
        const temppath = res.tempFilePaths[0];
        //获取图片的宽高信息
        wx.getImageInfo({
          src: temppath,
          success: (res) => {          
          const w = res.width;
          const h = res.height;
          this.setData({canvasHeight: h,canvasWidth: w,},
            () => {
              //canvas 画一张图片
              ctx.drawImage(temppath, 0, 0, w, h);
              ctx.draw();
              setTimeout(() => {
                //获取画布里的图片数据
                wx.canvasGetImageData({
                  canvasId: 'secondCanvas',
                  x: 0, y: 0,
                  width: w,
                  height: h,
                  success: (res) => {
                    const pix = res.data;
                    const opt = { 
                      deviceId: this.data.deviceId,
                      serviceId: this.data.serviceId, 
                      characteristicId: this.data.writeId,
                      lasterSuccess: this.onSendSuccess
                    };
                    //----ESC指令打印----
                    /*
                    const sendImageinfo = zksdk.overwriteImageData({
                      imageData: pix,
                      width: w,
                      height: h,
                      threshold: 190,
                    });
                    console.log(sendImageinfo);
                    //打印图片
                    zksdk.printImage(opt, sendImageinfo);
                    */
                    /*const sendImageinfo = zksdk.overwriteImageData2({
                      imageData: pix,
                      width: w,
                      height: h,
                      threshold: 190,
                    });
                    console.log(sendImageinfo);*/

                    /*let strImg=zksdk.addCPCLImageCmd(10,10, {
                      imageData: pix,  width: w, height: h, threshold: 190,
                    });*/
                    var d1 = new Date();
                    var n1 = d1.getTime();
                    console.log("start time:",n1);

                    let strCmd =zksdk.CreatCPCLPage(576,h+60,1);                    
                    strCmd +=zksdk.addCPCLImageCmd(10,10,{imageData:pix, width:w, height:h, threshold:190,});                    
                    strCmd += zksdk.addCPCLPrint();

                    let buffer =gbk.strToGBKByte(strCmd);
                    buffer=pako.myGzip(buffer);
                    //console.log(buffer)
                  
                    var datalen=20;
                    if (app.globalData.platform == 'ios')
                    {
                      console.log('platform:', app.globalData.platform)          
                      datalen=120;
                    }
                    const opt2 = { 
                      deviceId: this.data.deviceId, 
                      serviceId: this.data.serviceId, 
                      characteristicId: this.data.writeId,
                      value:buffer,
                      lasterSuccess: this.onSendSuccess,
                      onceLength:datalen
                    };
                    console.log(strCmd);    
                    
                    var d2 = new Date();
                    var n2 = d2.getTime();
                    console.log("end time1:",n2);
                    var usedTime1 = n2 - n1; //两个时间戳相差的毫秒数
                    console.log("Delta time1:",usedTime1);

                    zksdk.sendDataToDevice(opt2);

                    var d3 = new Date();
                    var n3 = d3.getTime();
                    console.log("end time1:",n3);
                    var usedTime2 = n3 - n2; //两个时间戳相差的毫秒数
                    console.log("Delta time2:",usedTime2);
                  },
                });
              }, 100);
            },
          );
          },
        });
      },
    });
    
  },
      
  //热点名和密码输入框事件
  WiFiNameInput: function (e) {
    var that = this;
    that.setData({
      WiFiName: e.detail.value
    });
    that.data.WiFiName = e.detail.value;
    console.log('that.data.WiFiName:', that.data.WiFiName);
    //console.log(gbk.stringToArrayBuffer(that.data.WiFiName)); 
    //console.log(util.str2ab(that.data.WiFiName));
  },
  passWdInput: function (e) {
    var that = this;
    that.setData({
      WiFiPassword: e.detail.value
    })
    console.log('that.data.WiFiPassword:', that.data.WiFiPassword)
  },
  //------参数封装指令------
  SetDevicePar: function (setname, setdata, flg) {
    let data1 = gbk.stringToArrayBuffer(setname); //util.str2ab(setname);
    let data2;
    if(flg==3) data2 = setdata;
    else data2 = gbk.stringToArrayBuffer(setdata);
    
    let a = new Uint8Array(data1, 0, data1.byteLength);
    let b = new Uint8Array(data2, 0, data2.byteLength);
    //console.log('a', a)
    //console.log('b', b)
    var blen = b.byteLength;
    if (blen <= 1) blen = 0;

    let buffer = new ArrayBuffer(a.byteLength + blen + 10);
    var vb = new Uint8Array(buffer, 0);
    vb[0] = 0x1F; vb[1] = 0x52;
    vb[2] = buffer.byteLength - 4; vb[3] = 0;
    vb[4] = 0x30; vb[5] = flg;
    vb[6] = a.byteLength; vb[7] = 0;
    vb[8] = blen; vb[9] = 0;
    for (var i = 0; i < a.length; i++) vb[10 + i] = a[i];
    for (var i = 0; i < blen; i++) vb[10 + i + a.length] = b[i];
    return buffer;
  },  
  GetDevicePar: function (Getname, flg) {
    let data = util.str2ab(Getname);    
    let a = new Uint8Array(data, 0, data.byteLength);    
    
    let buffer = new ArrayBuffer(a.byteLength+6);
    var vb = new Uint8Array(buffer, 0);
    vb[0] = 0x1F; vb[1] = 0x52;
    vb[2] = buffer.byteLength - 4; vb[3] = 0;
    vb[4] = 0x20; vb[5] = flg;    
    for (var i = 0; i < a.length; i++) vb[6 + i] = a[i];  
    return buffer;
  },
  /**
   * 发送 WiFi参数到设备中
   */
  btn_SetWiFiPar: function () {
    var that = this;
    console.log('that.data.deviceId:', that.data.deviceId,'Set WiFi Parameter')
    var a1 = that.SetDevicePar("WIFI_CONFIG_SSID", this.data.WiFiName, 1);
    var a2 = that.SetDevicePar("WIFI_CONFIG_PASSWORD", this.data.WiFiPassword, 1);
    var a3 = that.SetDevicePar("reg_value_save", "", 18);
    var a4 = that.SetDevicePar("power_reset", "", 2);
    let buffer = new ArrayBuffer(a1.byteLength + a2.byteLength + a3.byteLength + a4.byteLength);
    var vb = new Uint8Array(buffer, 0);
    var vblen = 0;
    let data = new Uint8Array(a1, 0, a1.byteLength);
    for (var i = 0; i < a1.byteLength; i++) vb[vblen++] = data[i];
    data = new Uint8Array(a2, 0, a2.byteLength);
    for (var i = 0; i < a2.byteLength; i++) vb[vblen++] = data[i];
    data = new Uint8Array(a3, 0, a3.byteLength);
    for (var i = 0; i < a3.byteLength; i++) vb[vblen++] = data[i];
    data = new Uint8Array(a4, 0, a4.byteLength);
    for (var i = 0; i < a4.byteLength; i++) vb[vblen++] = data[i];
    //console.log('buffer:', buffer);
    console.log('wifiname:', a1);
    var datalen=20;
    if (app.globalData.platform == 'ios')
    {
      console.log('platform:', app.globalData.platform)          
      datalen=120;
    }
    const opt = { 
      deviceId: this.data.deviceId, 
      serviceId: this.data.serviceId, 
      characteristicId: this.data.writeId,
      value:buffer,
      lasterSuccess: this.onSendSuccess,
      onceLength:datalen
    };
    zksdk.sendDataToDevice(opt);
  },

  //LAN参数输入
  LANIPInput: function (e) {
    var that = this;
    that.setData({LANIPValue: e.detail.value});
    that.data.LANIP = e.detail.value;
    wx.setStorageSync('LANIP', e.detail.value);  
  },
  LANMaskInput: function (e) {
    var that = this;
    that.setData({LANMaskValue: e.detail.value});
    that.data.LANMask = e.detail.value;
    wx.setStorageSync('LANMask', e.detail.value);
  },
  LANGateWayInput: function (e) {
    var that = this;
    that.setData({LANGateWayValue: e.detail.value});
    that.data.LANGateWay = e.detail.value;
    wx.setStorageSync('LANGateWay', e.detail.value);  
  },
  /**
   * 发送LAN参数到设备中
   */
   IptoArray:function (IP){
    var Arr =  new ArrayBuffer(4);
    var view1 = new DataView(Arr);
    var result = IP.replace(/\d+\.?/ig,function(a){
      a = parseInt(a); 
      return (a > 15 ? "" : "0") + a.toString(16);
    }) 
    view1.setUint32(0,parseInt(result,16));
    console.log(Arr)
    return Arr;
  },
   btn_SetLANPar: function () {
    var that = this;    
    console.log('that.data.deviceId:', that.data.deviceId,'Set Lan Parameter')    
    var a1 = that.SetDevicePar("LAN_CONFIG_IPADDRESS", that.IptoArray(this.data.LANIP), 3);
    var a2 = that.SetDevicePar("LAN_CONFIG_NETMASK", that.IptoArray(this.data.LANMask), 3);
    var a3 = that.SetDevicePar("LAN_CONFIG_GATEWAY", that.IptoArray(this.data.LANGateWay), 3);
    var a4 = that.SetDevicePar("reg_value_save", "", 18);
    var a5 = that.SetDevicePar("power_reset", "", 2);
    let buffer = new ArrayBuffer(a1.byteLength + a2.byteLength + a3.byteLength + a4.byteLength+a5.byteLength);
    var vb = new Uint8Array(buffer, 0);
    var vblen = 0;
    let data = new Uint8Array(a1, 0, a1.byteLength);
    for (var i = 0; i < a1.byteLength; i++) vb[vblen++] = data[i];    
    data = new Uint8Array(a2, 0, a2.byteLength);
    for (var i = 0; i < a2.byteLength; i++) vb[vblen++] = data[i];
    data = new Uint8Array(a3, 0, a3.byteLength);
    for (var i = 0; i < a3.byteLength; i++) vb[vblen++] = data[i];
    data = new Uint8Array(a4, 0, a4.byteLength);
    for (var i = 0; i < a4.byteLength; i++) vb[vblen++] = data[i];
    data = new Uint8Array(a5, 0, a5.byteLength);
    for (var i = 0; i < a5.byteLength; i++) vb[vblen++] = data[i];
    //console.log('buffer:', buffer);
    var datalen=20;
    if (app.globalData.platform == 'ios')
    {
      console.log('platform:', app.globalData.platform)          
      datalen=120;
    }
    const opt = { 
      deviceId: this.data.deviceId, 
      serviceId: this.data.serviceId, 
      characteristicId: this.data.writeId,
      value:buffer,
      lasterSuccess: this.onSendSuccess,
      onceLength:datalen
    };
    zksdk.sendDataToDevice(opt);
  },

  onChangeShowWiFi: function () {
    var that = this;
    console.log("onChangeshowViewWiFi="+that.data.showViewWiFi);
    that.setData({
      showViewWiFi: (!that.data.showViewWiFi)
    })
  },
  onChangeShowLAN: function () {
    var that = this;
    console.log("onChangeshowViewLAN="+that.data.showViewLAN);
    that.setData({
      showViewLAN: (!that.data.showViewLAN)
    })
  },

  onUnload:function(){
    zksdk.closeBLEConnection(this.data.deviceId);
    zksdk.stopBlueDevicesDiscovery();     
     
  }
})

    