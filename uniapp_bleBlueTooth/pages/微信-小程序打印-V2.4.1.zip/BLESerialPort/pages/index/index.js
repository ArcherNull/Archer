//index.js
//获取应用实例
const app = getApp()
var util = require('../../utils/util.js');


import * as zksdk from '../../utils/bluetoolth';

const errMsg = {
    10000: '未初始化蓝牙模块',
    10001: '蓝牙未打开',
    10002: '没有找到指定设备',
    10003: '连接失败',
    10004: '没有找到指定服务',
    10005: '没有找到指定特征值',
    10006: '当前连接已断开',
    10007: '当前特征值不支持此操作',
    10008: '系统上报异常',
    10009: '系统版本低于 4.3 不支持BLE'
};
/*var mydevices = [
  {deviceId: "C0:12:63:59:94:73", name: "QR-386A-9473L", RSSI: -71},
  {deviceId: "76:74:E7:ED:FA:9F", name: "未知设备", RSSI: -86},
  {deviceId: "4A:D5:17:E1:38:82", name: "CS3_2233", RSSI: -82},
  {deviceId: "0B:A3:DB:07:11:CC", name: "未知设备", RSSI: -93},
  {deviceId: "17:37:4D:15:0C:CD", name: "未知设备", RSSI: -42},
  {deviceId: "59:5F:36:87:12:81", name: "未知设备", RSSI: -79},
  {deviceId: "09:C9:F5:1B:31:C6", name: "未知设备", RSSI: -90},
  {deviceId: "0E:23:DC:B9:10:97", name: "未知设备", RSSI: -69},
  {deviceId: "1B:BE:A6:89:0F:60", name: "CS3_1234", RSSI: -28}
  ];*/
  //var b64Data   = 'H4sIAAAAAAAAAJ3UMQ7CMAwF0KugP2ewEzdpcxXUAbWAOiHUMqCqdyeVQAobfGXIYL8hP5ZXnEdkeNEk6vUgXTbLonC4zMjHFY/5Wm511ekdTsOCLKVp2rlIKOA2jTuBot/cr7BhobEwsbAloY8kDGyqoQ5H/oHsdwQ21cCmaspCz0L2jcYOgLHhNGw4TT1yVmBpuS9PZHWY35siqnxvimEvpE9FY4peQhfbhO0FDnuFqWAEAAA=';
  //var ticketData = '{"ed":"20170121 09:44:01","fs":[{"usg":[1,1,1,1,1,1,1],"act":0,"fid":"003","oids":["1"]},{"usg":[1,1,1,1,1,1,1],"act":0,"fid":"005","oids":["1"]},{"usg":[1,1,1,1,1,1,1],"act":0,"fid":"004","oids":["1"]},{"usg":[1,1,1,1,1,1,1],"act":0,"fid":"007","oids":["1"]},{"usg":[1,1,1,1,1,1,1],"act":0,"fid":"008","oids":["1"]},{"usg":[1,1,1,1,1,1,1],"act":0,"fid":"026","oids":["1"]},{"usg":[1,1,1,1,1,1,1],"act":0,"fid":"033","oids":["1"]},{"usg":[1,1,1,1,1,1,1],"act":0,"fid":"034","oids":["0"]},{"usg":[1,1,1,1,1,1,1],"act":0,"fid":"035","oids":["1"]},{"usg":[1,1,1,1,1,1,1],"act":0,"fid":"037","oids":["1"]},{"usg":[1,1,1,1,1,1,1],"act":0,"fid":"038","oids":["1"]},{"usg":[1,1,1,1,1,1,1],"act":0,"fid":"041","oids":["1"]},{"usg":[1,1,1,1,1,1,1],"act":0,"fid":"042","oids":["1"]},{"usg":[1,1,1,1,1,1,1],"act":0,"fid":"047","oids":["1"]},{"usg":[1,1,1,1,1,1,1],"act":0,"fid":"046","oids":["1"]},{"usg":[1,1,1,1,1,1,1],"act":0,"fid":"048","oids":["1"]},{"usg":[1,1,1,1,1,1,1],"act":0,"fid":"051","oids":["1"]},{"usg":[1,1,1,1,1,1,1],"act":0,"fid":"053","oids":["4"]}],"qty":1,"sd":"20161021 09:44:01","cd":"72016102116762039687"}';
//var app = getApp()
Page({
  data: {
    motto: '打印测试 V2.4.1\r\n 请选择测试方式',
    userInfo: {},
    url1:'/images/Bluetooth1.png',
    deviceId:'',
    name:''
  },

  //事件处理函数
  bindViewTap: function() {
    wx.navigateTo({
      url: '../logs/logs'
    })
  },
  bindViewTapScan:function() {
    wx.navigateTo({
      url: '../bluetooththr/bluetooththr'
    })
  },
  bindViewTapLink:function() {
    var deviceId = wx.getStorageSync('deviceId');
    var name = wx.getStorageSync('name');
    console.log(deviceId,name);
    zksdk.openBlue()
      .then((res) => {
        //搜寻设备
        zksdk.startBluetoothDevicesDiscovery();
        //监听寻找新设备
        zksdk.onfindBlueDevices(this.onGetDevice);
        wx.navigateTo({
          url: '../bluetooththrsec/bluetooththrsec?deviceId='+deviceId+'&name='+name,
          success: function(res){
            console.log('---bindViewTap---点击连接蓝牙--success--',res)
          },
          fail: function(res) {
            console.log('---bindViewTap---点击连接蓝牙--fail--',res)
          }
        })
      })
      .catch((res) => {
        console.log('catch res:'+res);
        const coode = res.errCode ? res.errCode.toString() : '';
        const msg = errMsg[coode];
        wx.showToast({
          title: msg || coode,
          icon: 'none',
        });
      });
  },
  bindViewScanPrintLink:function() {
    wx.navigateTo({
      url: '../scanprint/scanprint'
    })
  },

  bindViewCloudPrintLink:function() {
    wx.redirectTo({
      url: '../cloudprint/cloudprint'
    })
  },

  compare:function (property) {
    return function (a, b) {
      var nameA = a.name.toUpperCase(); // ignore upper and lowercase
      var nameB = b.name.toUpperCase(); // ignore upper and lowercase
      if (nameA < nameB) {
        return -1;
      }
      if (nameA > nameB) {
        return 1;
      }
      return 0;
    }
  },
  valuecompare: function (property) {
    return function (a, b) {
      var value1 = a[property];
      var value2 = b[property];
      return value2 - value1;
    }
  },

  onLoad: function () {
    console.log('onLoad')

    /*var newDevices = mydevices;
    newDevices.sort(this.valuecompare("RSSI"));
    if(newDevices[0].RSSI > -30)
    {
      console.log(newDevices[0]);
    }
    newDevices.sort(this.compare("name"));
    console.log(newDevices);  */
    //var d = new Date();
    //var n1 = d.getTime();
    //console.log(d,n1);

    var that = this
    //分享
    wx.showShareMenu({
      withShareTicket: true
    });

    //调用应用实例的方法获取全局数据
    that.data.deviceId = wx.getStorageSync('deviceId');
    that.data.name = wx.getStorageSync('name');
    app.getUserInfo(function(userInfo){
      //更新数据
      that.setData({
        userInfo:userInfo
      })

    });

  }
})
