//import { wxAsyncPromise } from '../../wx-weapp-tool/index';
import * as zksdk from '../../utils/bluetoolth';
var util = require('../../utils/util.js');

const errMsg = {
    10000: '未初始化蓝牙模块',
    10001: '蓝牙未打开',
    10002: '没有找到指定设备',
    10003: '连接失败',
    10004: '没有找到指定服务',
    10005: '没有找到指定特征值',
    10006: '当前连接已断开',
    10007: '当前特征值不支持此操作',
    10008: '系统上报异常',
    10009: '系统版本低于 4.3 不支持BLE'
};

function debounce(func, wait) {
    let timer = null;
    return function(opt) {
        clearTimeout(timer);
        timer = setTimeout(() => {
            func && func.call(this, opt);
        }, wait || 60);
    };
}

function Bytes2Float32(src)
{
  // Create a buffer
  var data = new Uint8Array(4);
  var buf = new ArrayBuffer(4);
  // Create a data view of it
  var view = new DataView(buf);
  for(let i=0;i<4;i++)    data[i]=src[3-i];
  // set bytes
  data.forEach(function (b, i) {
    view.setUint8(i, b);
  });
  // Read the bits as a float; note that by doing this, we're implicitly
  // converting it from a 32-bit float into JavaScript's native 64-bit double
  var num = view.getFloat32(0);
  num = num.toFixed(2); 
  // Done
  console.log(num);   
  return num;  
}

/**
 * 搜索设备界面
 */
Page({
  data: {
    logs: [],
    list:[],  
    mydevices: [],  
    deviceName: '',
    deviceId: '',
    advdata:[],
    rssi:'-95',
    msg:'',
    BTName:''    
  },
  
 
  onLoad: function () {
    console.log('onLoad')
    //分享
    wx.showShareMenu({
      withShareTicket: true
    });
    var that = this;
    //that.setData({ msg: "Hello" })
    that.setData({
      BTName: "SCA"
    });    
    that.data.BTName = "SCA";
    zksdk.openBlue()
      .then((res) => {
        //搜寻设备
        zksdk.startBluetoothDevicesDiscovery({ allowDuplicatesKey: true, interval: 100 });
        //监听寻找新设备
        zksdk.onfindBlueDevices(this.onGetDevice)})
      .catch((res) => {
        console.log('catch res:'+res);
        const coode = res.errCode ? res.errCode.toString() : '';
        const msg = errMsg[coode];
        wx.showToast({
          title: msg || coode,
          icon: 'none',
        });
      });  
  },

  BTNameInput: function (e) {
    var that = this;
    that.setData({
      BTName: e.detail.value
    });
    that.data.BTName = e.detail.value;
    console.log('that.data.BTName:', that.data.BTName);
  },


    //过滤设备列表 
    getNewDevicesList(devices,name) {
      var that = this;    
      var newDevices = devices;
      var rssi = that.data.rssi;
      console.log('RSSI:', rssi);    
        
      //按RSSI过滤
      for (var i = 0; i < newDevices.length;) {        
        if (newDevices[i].RSSI < rssi)   newDevices.splice(i, 1);
        else i++;     
      }
      
      // 按名字过滤
      if(name!=''){
        for (var i = 0; i < newDevices.length;) {        
          if (newDevices[i].name.indexOf(name)==0)  i++;        
          else        newDevices.splice(i, 1);        
        }
      }
      console.log("Get Data");
      // 广播数据提取传感器重量和长度值
      for (var i = 0; i < newDevices.length;i++) {  
        if (newDevices[i].hasOwnProperty('serviceData')){          
          //console.log(newDevices[i].serviceData);        
          let obj = newDevices[i].serviceData;
          for (let k in obj) {
            //console.log(k, ":", obj[k]);
            //console.log(obj[k].byteLength);
            if (obj[k].byteLength == 12) {
              var a = obj[k].slice(2, 11);
              var buffer = new Uint8Array(a);
              console.log(buffer);
           
              if (buffer[0] == 0 || buffer[0] == 1){ //台秤
                console.log("TWeight");
                var buffer = obj[k].slice(2, 11);
                var data1 = new Uint8Array(buffer, 1, 4);
                var data2 = new Uint8Array(buffer, 5, 4);
                //console.log(data1, "-", data2);
                var w1 = Bytes2Float32(data1);
                var w2 = Bytes2Float32(data2);
                console.log(w1, "-", w2);
                newDevices[i].TWeight = w1;  
                newDevices[i].TAllW = w2;  
              }   
              if (buffer[0] == 17 || buffer[0] == 16) { //钩秤
                console.log("GWeight");
                var buffer = obj[k].slice(2, 11);
                var data1 = new Uint8Array(buffer, 1, 4);
                var data2 = new Uint8Array(buffer, 5, 4);
                //console.log(data1, "-", data2);
                var w1 = Bytes2Float32(data1);
                var w2 = Bytes2Float32(data2);
                console.log(w1, "-", w2);
                newDevices[i].GWeight = w1;
                newDevices[i].GAllW = w2;  
              } 
              if (buffer[0] == 33 || buffer[0] == 32) { //卷尺
                console.log("Len");
                var buffer = obj[k].slice(2, 11);   
                var data = new Uint8Array(buffer, 1, 8); 
                var len1=data[0]+data[1]*255;    
                var len2 = data[2] + data[3] * 255;    
                var len3 = data[4] + data[5] * 255;    
                var len4 = data[6] + data[7] * 255;            
                console.log(len1, "-", len2, "-",len3, "-", len4);     
                newDevices[i].LEN = len1;
                newDevices[i].Length = len2;   
                newDevices[i].Width = len3; 
                newDevices[i].Height = len4;                          
              }                          
            }
          }                   
        } 
      }
           
      /*
        const ids = [];
        //过滤
        const devs = devices
            .filter((item) => !(item.RSSI > 0 || item.name == '未知设备'))
            .map((item) => {
                ids.push(item.deviceId);
                return {
                    rssi: item.RSSI,
                    name: item.name,
                    devId: item.deviceId,
                };
            });
        //过滤重复
        const filterId = [...new Set(ids)];
        const newDevices = [];
        while (filterId.length) {
            const id = filterId.shift();
            for (let index = 0; index < devs.length; index++) {
                const item = devs[index];
                if (item.devId === id) {
                    newDevices.push(item);
                    break;
                }
            }
        }*/
        return newDevices;
    },
    
  //获取设备列表
  onGetDevice:function(res){
    var that = this;   
    var dev; 
     {
      console.log('onGetDevice', res); 
      console.log('onGetDevice', that.data.BTName); 
      dev = this.getNewDevicesList(res, that.data.BTName)
      this.setData({
        mydevices: dev
      });     
    }  
  },

  onShow:function(){
    console.log("OnShow");
    var data = [184, 30, 133, 62]; //0.62kg
    Bytes2Float32(data);
  },

  onUnload:function(){
    //----关闭扫描蓝牙设备----
    zksdk.stopBlueDevicesDiscovery();
  },
  
  
  // 正在滑动
  sliderRSSIchange: function (e) {
    var that = this;
    that.data.rssi = e.detail.value; 
    console.log("sliderChange", that.data.rssi);
  },


})