//import { wxAsyncPromise } from '../../wx-weapp-tool/index';
import * as zksdk from '../../utils/bluetoolth';
var util = require('../../utils/util.js');
const app = getApp()
var gbk = require('../../utils/printUtil-GBK.js');

const errMsg = {
    10000: '未初始化蓝牙模块',
    10001: '蓝牙未打开',
    10002: '没有找到指定设备',
    10003: '连接失败',
    10004: '没有找到指定服务',
    10005: '没有找到指定特征值',
    10006: '当前连接已断开',
    10007: '当前特征值不支持此操作',
    10008: '系统上报异常',
    10009: '系统版本低于 4.3 不支持BLE'
};

function debounce(func, wait) {
    let timer = null;
    return function(opt) {
        clearTimeout(timer);
        timer = setTimeout(() => {
            func && func.call(this, opt);
        }, wait || 60);
    };
}
var timer;
var connectedflg;
/**
 * 搜索设备界面
 */
Page({
  data: {
    logs: [],
    list:[],  
    mydevices: [],  
    deviceId: '',
    name: '',
    services: [],
    serviceId: '', 
    writeId:'',
    readId:'',
    advdata:[],
    rssi:'-95',
    disRSSI:'-35',
    msg:'',
    BTName:''
  },
  
  onLoad: function () {
    var that = this;   
    console.log('onLoad')
    var RSSIFilter = wx.getStorageSync('RSSIFilter');
    var RSSIDistance = wx.getStorageSync('RSSIDistance');
    var btName = wx.getStorageSync('BTName');
    console.log(RSSIFilter,RSSIDistance,btName)
    if(RSSIDistance=='' || RSSIFilter==''){
      console.log('Need Init');
      RSSIDistance=-35;
      RSSIFilter=-85;
    }
    that.data.disRSSI = RSSIDistance; 
    that.data.rssi = RSSIFilter; 
    that.data.BTName=btName;
    that.setData({  RSSIDistanceValue: RSSIDistance  });
    that.setData({  RSSIFilterValue: RSSIFilter  });
    that.setData({  BTNameValue: btName  });
    connectedflg=0;
    //var timerName = setTimeout(this.onTimeOut, 2000);
    this.startAutoPrint(0);
    zksdk.openBlue()
      .then((res) => {
        //搜寻设备
        //zksdk.startBluetoothDevicesDiscovery({services: ['FEE7'], allowDuplicatesKey: true, interval: 100,powerLevel:"high"});
        zksdk.startBluetoothDevicesDiscovery({services: ['FFF0'],allowDuplicatesKey: true, interval: 200,powerLevel:"high"});
        //监听寻找新设备
        zksdk.onfindBlueDevices(this.onGetDevice)})
      .catch((res) => {
        console.log('catch res:'+res);
        const coode = res.errCode ? res.errCode.toString() : '';
        const msg = errMsg[coode];
        wx.showToast({
          title: msg || coode,
          icon: 'none',
        });
      });

  },


  //---连接成功----
 onConnectSuccess(res){   
  var that = this;   
  console.log('onConnectSuccess', res); 
  zksdk.getBLEDeviceServices(that.data.deviceId, this.onGetServicesSuccess, this.onGetServicesFail);      
},
//---连接失败----
onConnectFail(res){    
  console.log('onConnectFail', res);     
  connectedflg=0;   
},
 //---Services获取成功----
 onGetServicesSuccess(res){    
  var that = this;  
  console.log('onGetServicesSuccess', res); 
  this.setData({ services: res.serviceId });    
  zksdk.getDeviceCharacteristics(that.data.deviceId, that.data.services, this.onGetCharacterSuccess, this.onGetCharacterFail);
},
//---Services获取失败----
onGetServicesFail(res){    
  console.log('onGetServicesFail', res);     
  zksdk.closeBLEConnection(this.data.deviceId);
  connectedflg=0;   
},
//---Characteristics获取成功----
onGetCharacterSuccess(res){
    console.log('onGetCharacterSuccess servid ', res.serviceId);      
    console.log('write character ',res.writeId);
    console.log('read character ',res.readId);
    this.setData({ 
        serviceId: res.serviceId,  
        writeId: res.writeId, 
        readId: res.readId,
    });          
    this.setData({btn_disabled:false});
    console.log('Enable button');
    //---停止扫描蓝牙设备---------
    zksdk.stopBlueDevicesDiscovery();
    //onPrint();
    setTimeout(res=>{
      this.onPrint()
    },500)
},
//---Characteristics获取失败----
onGetCharacterFail(res){
  console.log('onGetCharacterFail', res);
  zksdk.closeBLEConnection(this.data.deviceId);
  connectedflg=0;
},
//----发送最终完毕-----
onSendSuccess:function()
{
  console.log("lasterSuccess");
  zksdk.closeBLEConnection(this.data.deviceId);
  zksdk.startBluetoothDevicesDiscovery({allowDuplicatesKey: true, interval: 200,powerLevel:"high"});
  connectedflg=0;
},
onPrint: function () {
  var that = this;
  //let buffer = wx.base64ToArrayBuffer("");  
  let strCmd =zksdk.CreatCPCLPage(560,500,1,0);  
  strCmd += zksdk.addCPCLText(10,0,'4','3',0,'8.14');
  strCmd += zksdk.addCPCLBarCode(270,0,'128',80,0,1,1,'00051');
  strCmd += zksdk.addCPCLText(290,80,'7','2',0,'00051');
  strCmd += zksdk.addCPCLText(40,110,'3','0',0,'CHICKEN FEET (BONELESS)-Copy-Copy');
  strCmd += zksdk.addCPCLSETMAG(2,2);
  strCmd += zksdk.addCPCLText(40,150,'55','0',0,'无骨鸡爪 一盒（约1.5磅）'); 
  strCmd += zksdk.addCPCLSETMAG(0,0);
  strCmd += zksdk.addCPCLText(40,220,'0','24',0,'123㎡');
  strCmd += zksdk.addCPCLText(350,180,'7','2',0,'2019-08-12');
  
  strCmd += zksdk.addCPCLLocation(2);
  strCmd += zksdk.addCPCLQRCode(0,220,'M', 2, 6, 'qr code test');
  //strCmd += zksdk.addCPCLGAP();
  strCmd += zksdk.addCPCLPrint();
  console.log(strCmd);
  
  let buffer = gbk.strToGBKByte(strCmd);
  //console.log(buffer);
  var datalen=20;
  if (app.globalData.platform == 'ios')
  {
    console.log('platform:', app.globalData.platform)          
    datalen=120;
  }
  const opt = { 
    deviceId: this.data.deviceId, 
    serviceId: this.data.serviceId, 
    characteristicId: this.data.writeId,
    value:buffer,
    lasterSuccess: this.onSendSuccess,
    onceLength:datalen
  };
  //const opt = { deviceId: this.data.deviceId, ...this.character };
  zksdk.sendDataToDevice(opt);
},

//---定时查询 RSSI 连接打印----
startAutoPrint: function (time){
  var that = this;   
  //console.log("startAutoPrint"+time)
  time++;  
  //---RSSI排序---
  var newDevices = that.data.mydevices;
  if(newDevices.length>0){
    newDevices.sort(this.valuecompare("RSSI"));
    if(newDevices[0].RSSI > that.data.disRSSI && newDevices[0].RSSI < 0 && connectedflg==0)
    {
      if(that.data.deviceId != newDevices[0].deviceId){
        zksdk.stopBlueDevicesDiscovery();
        console.log(newDevices[0]);
        that.data.deviceId=newDevices[0].deviceId;    
        connectedflg=1;            
        zksdk.createBLEConnection(that.data.deviceId, this.onConnectSuccess, this.onConnectFail);  
      }      
    }
    if(that.data.deviceId != ""){
      for (var i = 0; i < newDevices.length; i++) {        
        if(newDevices[i].deviceId  == that.data.deviceId){
          if(newDevices[i].RSSI < that.data.disRSSI){
            that.data.deviceId="";
          }
        }  
      }
    }

  }  
  //--再次启动定时器----  
  this.timer = setTimeout(res=>{
      this.startAutoPrint(time)
  },500)
},
  valuecompare: function (property) {
    return function (a, b) {
      var value1 = a[property];
      var value2 = b[property];
      return value2 - value1;
    }
  },
  compare:function (property) {
    return function (a, b) {    
      var nameA = a.name.toUpperCase(); // ignore upper and lowercase
      var nameB = b.name.toUpperCase(); // ignore upper and lowercase
      if (nameA < nameB)         return -1;    
      if (nameA > nameB)         return 1;    
      return 0;
    }
  },
    //过滤设备列表 
    getNewDevicesList(devices,name) {
      var that = this;    
      var newDevices = devices;
      var rssi = that.data.rssi;

      //按RSSI过滤
      for (var i = 0; i < newDevices.length;) {        
        if (newDevices[i].RSSI < rssi)   newDevices.splice(i, 1);
        else if(newDevices[i].RSSI == 0) newDevices.splice(i, 1);
        else i++;     
      }
      
      // 按名字过滤
      if(name!=''){
        for (var i = 0; i < newDevices.length;) {        
          if (newDevices[i].name.indexOf(name)==0)  i++;        
          else        newDevices.splice(i, 1);        
        }
      }
      // 按名字排序
      newDevices.sort(that.compare("id"));
      // 广播数据提取MAC地址
      /*for (var i = 0; i < newDevices.length;i++) {  
        if (newDevices[i].hasOwnProperty('advertisData')){          

          if (newDevices[i].advertisData.byteLength == 8) {            
            newDevices[i].advMac = util.buf2hex(newDevices[i].advertisData.slice(2, 7));
          }          
        } 
      } */
      return newDevices;
    },
    
  //获取设备列表
  onGetDevice:function(res){
    var that = this;   
    var dev; 
    console.log('onGetDevice');
     
      dev = this.getNewDevicesList(res, that.data.BTName)
      this.setData({
        mydevices: dev
      });      
  },

  onShow:function(){
    console.log("OnShow");
  },

  onUnload:function(){
    //----关闭扫描蓝牙设备----
    //if(connectedflg)      
    zksdk.closeBLEConnection(this.data.deviceId);
    zksdk.stopBlueDevicesDiscovery();
    clearTimeout(this.timer)
  },
  
   //点击事件处理
  bindViewTap: function(e) {
     /*console.log(e.currentTarget.dataset.title);
     console.log(e.currentTarget.dataset.name);
     var deviceId =  e.currentTarget.dataset.title;
     var name = e.currentTarget.dataset.name;
     wx.setStorageSync('deviceId', deviceId);
     wx.setStorageSync('name', name);
     wx.navigateTo({      
       url: '../bluetooththrsec/bluetooththrsec?deviceId='+deviceId+'&name='+name,
       success: function(res){
            console.log('---bindViewTap---点击连接蓝牙--success--',res)
       },
       fail: function(res) {
            console.log('---bindViewTap---点击连接蓝牙--fail--',res)
       }
     })*/
  },
    
  BTNameInput: function (e) {
    var that = this;
    that.setData({
      BTName: e.detail.value
    });
    that.data.BTName = e.detail.value;
    console.log('that.data.BTName:', that.data.BTName);
    wx.setStorageSync('BTName', that.data.BTName);
  },

  // 正在滑动
  sliderRSSIchange: function (e) {
    var that = this;
    that.data.rssi = e.detail.value; 
    console.log("sliderChange", that.data.rssi);
    wx.setStorageSync('RSSIFilter', that.data.rssi);    
  },
  sliderDistance: function (e) {
    var that = this;
    that.data.disRSSI = e.detail.value; 
    console.log("sliderDistance", that.data.disRSSI);
    wx.setStorageSync('RSSIDistance', that.data.disRSSI);    
  },


})