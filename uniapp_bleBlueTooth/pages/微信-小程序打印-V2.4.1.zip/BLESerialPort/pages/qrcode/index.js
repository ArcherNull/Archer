//index.js
var wxbarcode = require('../../utils/index.js');
var util=require("../../utils/util.js");

Page({
  data: {
    code: 'WIFI:T:WPA;S:;P:;;',  //"WIFI:T:WPA;S:ZICOX_AP;P:zicox258c2;;"
    logincode: 'Login:test,123',
    showView_WiFi: true,
    showView_Usr: false,
    showView_Par: false,
    showView_Time: false,
    ScreenBrightness: 0,
    TEST_ERROR_OFF:0,
    LabelValue:32,
    setInter:'',   //设置定时器
    items: [
      { value: 'WiFiSet', name: 'WiFi配置', checked: 'true' },
      { value: 'UserSet', name: '用户' },
      { value: 'ParSet', name: '设备'},
      { value: 'TimeSet', name: '对时'},
    ]
  },

  notification: function () {
    var that = this;
    setInterval(function () {
      var qrcode= "SETTING:RTC_TIME:"+util.FormatTime(new Date())+";";
      that.setData({timecode: qrcode});
      wxbarcode.qrcode('qrcode-time', qrcode, 420, 420);
    }, 5000);
    // 5秒更新一次
  },

  onLoad: function (options) {
    var that = this;

    that.setData({
      showView_WiFi: true,
      showView_Usr: false,
      showView_Par: false
    })
    //分享
    wx.showShareMenu({
      withShareTicket: true
    });
    var name = wx.getStorageSync('WiFiName');
    var pw = wx.getStorageSync('WiFiPassword');
    var ip = wx.getStorageSync('ServerIP');
    var port = wx.getStorageSync('ServerPort');
    var username = wx.getStorageSync('UserName');
    var password = wx.getStorageSync('Password');
    var LabelValue = wx.getStorageSync('LabelValue');
    if(LabelValue=="") LabelValue=32;
    var TEST_ERROR_OFF = wx.getStorageSync('TEST_ERROR_OFF');
    if(TEST_ERROR_OFF=="") TEST_ERROR_OFF=0;

    that.setData({ WiFiNameValue: name });
    that.setData({ WiFiPasswordValue: pw });
    that.setData({ ServerIPValue: ip });
    that.setData({ ServerPortValue: port });
    that.setData({ UserName: username });
    that.setData({ Password: password });
    that.setData({ LabelValue: LabelValue });
    that.data.TEST_ERROR_OFF =  TEST_ERROR_OFF;
    if(TEST_ERROR_OFF == 0)    that.setData({ TEST_ERROR_OFF_checked: false });
    else that.setData({ TEST_ERROR_OFF_checked: true });
    console.log("name", name, "PW", pw, TEST_ERROR_OFF);

    var qrcode = "WIFI:T:WPA;S:" + name + ";P:" + pw + ";" + "SN:" + ip + ";" + "SP:" + port + ";;";
    that.setData({ code: qrcode });
    wxbarcode.qrcode('qrcode', qrcode, 420, 420);
    qrcode = "Login:" + username + "," + password;
    that.setData({ logincode: qrcode });
    wxbarcode.qrcode('qrcode-login', qrcode, 420, 420);
    if(TEST_ERROR_OFF == 0) qrcode = "SETTING:LABEL_VDETECT_DV:" + LabelValue + ";"+"TEST_ERROR_OFF:0;"
    else  qrcode = "SETTING:LABEL_VDETECT_DV:" + LabelValue + ";"+"TEST_ERROR_OFF:1;"
    that.setData({parcode: qrcode});
    wxbarcode.qrcode('qrcode-par', qrcode, 420, 420);

    var qrcode= "SETTING:RTC_TIME:"+util.FormatTime(new Date())+";";
    that.setData({timecode: qrcode});
    wxbarcode.qrcode('qrcode-time', qrcode, 420, 420);
    this.notification();

    // 获取屏幕亮度
    wx.getScreenBrightness({
      success: function (res) {
        that.setData({
          ScreenBrightness: res.value
        })
      }
    })
    //设置屏幕亮度
    wx.setScreenBrightness({
      value: 1,    //屏幕亮度值，范围 0~1，0 最暗，1 最亮
    })
    console.log("Emd load")
  },
  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
    //清除计时器  即清除setInter
    clearInterval(this.data.setInter)
  },

  // 监听页面卸载
  onUnload: function () {
    var that = this;
    //设置屏幕亮度为原来亮度
    wx.setScreenBrightness({
      value: this.data.ScreenBrightness,
    })
    //清除计时器  即清除setInter
    clearInterval(that.data.setInter)
  },

  radioChange(e) {
    var that = this;
    console.log('radio发生change事件，携带value值为：', e.detail.value)
    const items = this.data.items
    for (let i = 0, len = items.length; i < len; ++i) {
      items[i].checked = (items[i].value === e.detail.value)
    }

    //this.setData({items})
    if (e.detail.value == 'WiFiSet')
      that.setData({
        showView_WiFi: true,
        showView_Usr: false,
        showView_Par: false,
        showView_Time:false
      })
    else if (e.detail.value == 'UserSet')
      that.setData({
        showView_WiFi: false,
        showView_Usr: true,
        showView_Par: false,
        showView_Time:false
      })
    else if (e.detail.value == 'ParSet')
      that.setData({
        showView_WiFi: false,
        showView_Usr: false,
        showView_Par: true,
        showView_Time:false
      })
      else if (e.detail.value == 'TimeSet')
      that.setData({
        showView_WiFi: false,
        showView_Usr: false,
        showView_Par: false,
        showView_Time:true
      })

  },
  //热点名和密码输入框事件
  WiFiNameInput: function (e) {
    var that = this;
    that.setData({
      WiFiNameValue: e.detail.value
    });
    that.data.WiFiName = e.detail.value;
    console.log('WiFiName:', that.data.WiFiNameValue);
    //var t = "WIFI:T:WPA;S:" + that.data.WiFiNameValue + ";P:" + that.data.WiFiPasswordValue+";;";
    var t = "WIFI:T:WPA;S:" + that.data.WiFiNameValue + ";P:" + that.data.WiFiPasswordValue + ";" +
      "SN:" + that.data.ServerIPValue + ";" + "SP:" + that.data.ServerPortValue + ";";
    wxbarcode.qrcode('qrcode', t, 420, 420);
    that.setData({
      code: t
    });
    wx.setStorageSync('WiFiName', that.data.WiFiNameValue);
  },

  passWdInput: function (e) {
    var that = this;
    that.setData({
      WiFiPasswordValue: e.detail.value
    })
    console.log('WiFiPassword:', that.data.WiFiPasswordValue)
    //var t = "WIFI:T:WPA;S:" + that.data.WiFiNameValue + ";P:" + that.data.WiFiPasswordValue + ";;";
    var t = "WIFI:T:WPA;S:" + that.data.WiFiNameValue + ";P:" + that.data.WiFiPasswordValue + ";" +
      "SN:" + that.data.ServerIPValue + ";" + "SP:" + that.data.ServerPortValue + ";";
    wxbarcode.qrcode('qrcode', t, 420, 420);
    that.setData({
      code: t
    });
    wx.setStorageSync('WiFiPassword', that.data.WiFiPasswordValue);
  },

  ServerIPInput: function (e) {
    var that = this;
    that.setData({
      ServerIPValue: e.detail.value
    })
    console.log('ServerIP:', that.data.ServerIPValue)
    //var t = "WIFI:T:WPA;S:" + that.data.WiFiNameValue + ";P:" + that.data.WiFiPasswordValue + ";;";
    var t = "WIFI:T:WPA;S:" + that.data.WiFiNameValue + ";P:" + that.data.WiFiPasswordValue + ";" +
      "SN:" + that.data.ServerIPValue + ";" + "SP:" + that.data.ServerPortValue + ";";
    wxbarcode.qrcode('qrcode', t, 420, 420);
    that.setData({
      code: t
    });
    wx.setStorageSync('ServerIP', that.data.ServerIPValue);
  },
  ServerPortInput: function (e) {
    var that = this;
    that.setData({
      ServerPortValue: e.detail.value
    })
    console.log('ServerPort:', that.data.ServerPortValue)
    //var t = "WIFI:T:WPA;S:" + that.data.WiFiNameValue + ";P:" + that.data.WiFiPasswordValue + ";;";
    var t = "WIFI:T:WPA;S:" + that.data.WiFiNameValue + ";P:" + that.data.WiFiPasswordValue + ";" +
      "SN:" + that.data.ServerIPValue + ";" + "SP:" + that.data.ServerPortValue + ";";
    wxbarcode.qrcode('qrcode', t, 420, 420);
    that.setData({
      code: t
    });
    wx.setStorageSync('ServerPort', that.data.ServerPortValue);
  },
  UsrNameInput: function (e) {
    var that = this;
    that.setData({
      UserName: e.detail.value
    })
    var t = "Login:" + that.data.UserName + "," + that.data.Password;
    wxbarcode.qrcode('qrcode-login', t, 420, 420);
    that.setData({
      logincode: t
    });
    wx.setStorageSync('UserName', that.data.UserName);
  },
  PasswordInput: function (e) {
    var that = this;
    that.setData({
      Password: e.detail.value
    })
    var t = "Login:" + that.data.UserName + "," + that.data.Password;
    wxbarcode.qrcode('qrcode-login', t, 420, 420);
    that.setData({
      logincode: t
    });
    wx.setStorageSync('Password', that.data.Password);
  },
  /*onChangeShowState: function () {
    var that = this;
    that.setData({
      showView_WiFi: (!that.data.showView_WiFi)
    })
  }*/
  LabelValueInput:function(e){
    var that = this;
    that.setData({
      LabelValue: e.detail.value
    })
    var t="";
    if(that.data.value == "TEST_ERROR_OFF"){
      t = "SETTING:LABEL_VDETECT_DV:" + that.data.LabelValue + ";"+"TEST_ERROR_OFF:"+"1;"
      wx.setStorageSync('TEST_ERROR_OFF', 1);
    }
    else{
      t = "SETTING:LABEL_VDETECT_DV:" + that.data.LabelValue + ";"+"TEST_ERROR_OFF:"+"0;"
      wx.setStorageSync('TEST_ERROR_OFF', 0);
    }
    wxbarcode.qrcode('qrcode-par', t, 420, 420);
    that.setData({
      parcode: t
    });
    wx.setStorageSync('LabelValue', that.data.LabelValue);
  },

  checkboxChange:function(e){
    console.log("checkboxChange "+e.detail.value)
    var that = this;
    var t="";
    if(e.detail.value == "TEST_ERROR_OFF"){
      t = "SETTING:LABEL_VDETECT_DV:" + that.data.LabelValue + ";"+"TEST_ERROR_OFF:"+"1;"
      wx.setStorageSync('TEST_ERROR_OFF', 1);
    }
    else{
      t = "SETTING:LABEL_VDETECT_DV:" + that.data.LabelValue + ";"+"TEST_ERROR_OFF:"+"0;"
      wx.setStorageSync('TEST_ERROR_OFF', 0);
    }
    wxbarcode.qrcode('qrcode-par', t, 420, 420);
    that.setData({
      parcode: t
    });

  }

})
