//import { wxAsyncPromise } from '../../wx-weapp-tool/index';
import * as zksdk from '../../utils/bluetoolth';
var util = require('../../utils/util.js');

const errMsg = {
    10000: '未初始化蓝牙模块',
    10001: '蓝牙未打开',
    10002: '没有找到指定设备',
    10003: '连接失败',
    10004: '没有找到指定服务',
    10005: '没有找到指定特征值',
    10006: '当前连接已断开',
    10007: '当前特征值不支持此操作',
    10008: '系统上报异常',
    10009: '系统版本低于 4.3 不支持BLE'
};

function debounce(func, wait) {
    let timer = null;
    return function(opt) {
        clearTimeout(timer);
        timer = setTimeout(() => {
            func && func.call(this, opt);
        }, wait || 60);
    };
}

/**
 * 搜索设备界面
 */
Page({
  data: {
    logs: [],
    list:[],  
    mydevices: [],  
    deviceName: '',
    deviceId: '',
    advdata:[],
    msg:'',
    rssi:'-95',
    BTName:''
  },
  
  onLoad: function () {
    var that = this;
    console.log('bluetooththr onLoad')
    var rssi = wx.getStorageSync('RSSI');
    var BTName = wx.getStorageSync('BTName');
    
    that.setData({  BTNameValue: BTName  });
    if(rssi==undefined)   that.setData({  RSSIValue: '-95'  });
    else  that.setData({  RSSIValue: rssi  });
    that.data.BTName=BTName;
    that.data.rssi=rssi;
    zksdk.openBlue()
      .then((res) => {
        //搜寻设备
        zksdk.startBluetoothDevicesDiscovery({ allowDuplicatesKey: true, interval: 500 });
        //监听寻找新设备
        zksdk.onfindBlueDevices(this.onGetDevice)})
      .catch((res) => {
        console.log('catch res:'+res);
        const coode = res.errCode ? res.errCode.toString() : '';
        const msg = errMsg[coode];
        wx.showToast({
          title: msg || coode,
          icon: 'none',
        });
      });

  },

  BTNameInput: function (e) {
    var that = this;
    that.setData({
      BTNameValue: e.detail.value
    });
    that.data.BTName = e.detail.value;
    wx.setStorageSync('BTName', e.detail.value);
    console.log('that.data.BTName:', that.data.BTName);
  },

  compare:function (property) {
    return function (a, b) {    
      var nameA = a.name.toUpperCase(); // ignore upper and lowercase
      var nameB = b.name.toUpperCase(); // ignore upper and lowercase
      if (nameA < nameB) {
        return -1;
      }
      if (nameA > nameB) {
        return 1;
      }    
      return 0;
    }
  },
    //过滤设备列表 
  getNewDevicesList(devices, name) {
    var that = this;
    var newDevices = devices;
    var rssi = that.data.rssi;
    console.log('RSSI:', rssi);

    //按RSSI过滤
    for (var i = 0; i < newDevices.length;) {
      if (newDevices[i].RSSI < rssi) newDevices.splice(i, 1);
      else i++;
    }

    // 按名字过滤
    if (name != '') {
      for (var i = 0; i < newDevices.length;) {
        if (newDevices[i].name.indexOf(name) == 0) i++;
        else newDevices.splice(i, 1);
      }
    }
    console.log("Get Mac");
    // 广播数据提取MAC地址
    for (var i = 0; i < newDevices.length; i++) {
      if (newDevices[i].hasOwnProperty('advertisData')) {
        console.log(newDevices[i].advertisData);
        console.log(newDevices[i].advertisData.byteLength);
        if (newDevices[i].advertisData.byteLength == 8) {
          //newDevices[i].add("adv");
          console.log("Adv MAC Address");
          console.log(util.buf2hex(newDevices[i].advertisData));
          newDevices[i].advMac = util.buf2hex(newDevices[i].advertisData.slice(2, 7));
        }
      }
    }

    newDevices.sort(this.compare("name"));
    return newDevices;
  },
    
  //获取设备列表
  onGetDevice:function(res){
    var that = this;   
    var dev; 
    {
      console.log('onGetDevice', res); 
      console.log('onGetDevice', that.data.BTName); 
      dev = this.getNewDevicesList(res, that.data.BTName)
      this.setData({
        mydevices: dev
      });                
    }       
  },

  onShow:function(){
    console.log("OnShow");
    //搜寻设备
    zksdk.startBluetoothDevicesDiscovery({ allowDuplicatesKey: true, interval: 500 });
    //监听寻找新设备
    zksdk.onfindBlueDevices(this.onGetDevice)
  },

  onUnload:function(){
    //----关闭扫描蓝牙设备----
    zksdk.stopBlueDevicesDiscovery();
  },
  
   //点击事件处理
  bindViewTap: function(e) {
    zksdk.stopBlueDevicesDiscovery();
     console.log(e.currentTarget.dataset.title);
     console.log(e.currentTarget.dataset.name);
     var deviceId =  e.currentTarget.dataset.title;
     var name = e.currentTarget.dataset.name;
     wx.setStorageSync('deviceId', deviceId);
     wx.setStorageSync('name', name);
     wx.navigateTo({      
       url: '../bluetooththrsec/bluetooththrsec?deviceId='+deviceId+'&name='+name,
       success: function(res){
            console.log('---bindViewTap---点击连接蓝牙--success--',res)
       },
       fail: function(res) {
            console.log('---bindViewTap---点击连接蓝牙--fail--',res)
       }
     })
     console.log("bindViewTap end")
  },
  
  // 正在滑动
  sliderRSSIchange: function (e) {
    var that = this;
    that.data.rssi = e.detail.value; 
    wx.setStorageSync('RSSI', e.detail.value);    
    console.log("sliderChange", that.data.rssi);
  },


})