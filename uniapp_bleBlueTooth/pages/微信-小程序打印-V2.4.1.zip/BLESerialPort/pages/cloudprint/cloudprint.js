var util = require('../../utils/util.js');
var mqtt = require('../../utils/mqtt.js');
var gbk = require('../../utils/printUtil-GBK.js');
var pako = require('pako');


/**
 * 扫码SN号并云打印
 * 参考：https://docs.emqx.cn/broker/v4.3/development/wechat-miniprogram.html
 * https://www.cnblogs.com/missmz/p/10483548.html
 * https://github.com/iAoe444/WeChatMiniEsp8266
 * 
 */
Page({
  data: {
    client: null,
    host: 'wxs://maxtrix.com.cn',  //'wxs://mqtt.hqq.vip/mqtt'  maxtrix.com.cn
    topic: 'sn/notice',
    publish:'sn/task',
    msg: 'Hello! I am from WeChat miniprogram',
    mqttOptions: {
      connectTimeout: 4000, // 超时时间
      clientId: 'wx_' + parseInt(Math.random() * 100 + 800, 10),
      port: 443,  //websocket for Mqtt Link port  10019
      username: 'admin',   // hqq
      password: 'password',  // hqq123456
    },
    result: "等待扫描"
  },

  scanCode: function () {
    var myThis = this;
    wx.scanCode({
      onlyFromCamera: true,
      scanType: ['barCode', 'qrCode'],
      success(res) {
        var isnum = /^\d+$/.test(res.result);
        console.log(isnum)
        //if (isnum) 
        {
          myThis.setData({
            result: res.result,
            scanType: res.scanType,
            topic: res.result+"/notice",
            publish:res.result+"/task",
          })
        }
        /*else {
          myThis.setData({
            result: "需要纯数字SN号"
          })
        }*/

      }
    })
  },

  CloudPrint: function () {
    this.publish();
  },

  connect() {
    var that = this;
    that.data.client = mqtt.connect(that.data.host, this.data.mqttOptions)
    console.log(that.data.host,this.data.mqttOptions)
    this.data.client.on('connect', () => {
      console.log('连接成功')
      wx.showToast({
        title: '连接成功'
      })
    })
  },
  disconnect() {
    this.data.client.end()
    wx.showToast({
      title: '断开连接成功'
    })
    console.log('断开连接')
  },
  subscribe() {
    this.data.client.subscribe(this.data.topic)
    wx.showToast({
      title: '主题订阅成功'
    })
  },
  unsubscribe() {
    this.data.client.unsubscribe(this.data.topic)
    wx.showToast({
      title: '取消订阅成功'
    })
  },
  publish() {
    let msg=this.data.msg;
    console.log('发布到:', this.data.publish)
    //let buffer = gbk.strToGBKByte(msg);
    //let arrayBuffer = new ArrayBuffer(buffer.byteLength);
    //let array = Array.prototype.slice.call(new Uint8Array(arrayBuffer));
    this.data.client.publish(this.data.publish, msg)
  },

  onLoad: function () {
    var that = this;
    that.data.msg="! 0 200 200 748 1\nPAGE-WIDTH 576\nLEFT\nBOX 10 10 560 740 3\nL 10 130 560 130 3\nL 10 170 560 170 3\nL 10 210 560 210 3\nL 10 250 560 250 3\nL 10 290 560 290 3\nL 10 330 560 330 3\nL 10 370 560 370 3\nL 10 410 560 410 3\nL 10 450 560 450 3\nL 10 490 560 490 3\nL 10 530 560 530 3\nL 10 570 560 570 3\nL 10 610 560 610 3\nSETBOLD 1\nSETMAG 1 2\nT 0 24 20 20 石家庄安邦物流安宝达运单\nSETBOLD 0\nSETMAG 1 1\nT 0 24 20 70 安邦物流园B区1号0311-89899808\nT 0 24 20 100 18233116611微\nT 0 24 20 140 单号:<barcode>  2020/12/12\nT 0 24 20 180 石家庄\nT 0 24 20 22015732184595\nT 0 24 20 260 数量：1                        货物名称：桌子\nT 0 24 20 300 发货人：杨龙 15863586585\nT 0 24 20 340 收货人：杨 4868268528633\nT 0 24 20 380 现付：1元                     到付：2元\nT 0 24 20 420 回单付：                      回单要求：无\nT 0 24 20 460 中转送货费：                 服务器方式：自提\nT 0 24 20 500  代收货款：                   包装方式：无\nT 0 24 20 540 小程序：物流专线联合   垫付：\nT 0 24 20 580 重量：                         体积：\nT 0 24 20 620 备注：\nCENTER\nB 128 2 1 40 20 660 <barcode>\nT 0 24 20 710 <barcode>\nGAP-SENSE\nFORM\nPRINT\n";    
    
    that.connect();
  },

  onunload:function(){
    this.disconnect();
  }

})